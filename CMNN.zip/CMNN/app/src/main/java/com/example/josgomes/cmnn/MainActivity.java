package com.example.josgomes.cmnn;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class MainActivity extends Activity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }


    public void OnButtonClick(View v) {
        if (v.getId() == R.id.Bdisplay) {
            Intent i = new Intent(MainActivity.this, segundaac.class);
            startActivity(i);
        }

    }

    public void OnButtonClick1(View v) {
        if (v.getId() == R.id.Bdisplay1) {
            Intent i = new Intent(MainActivity.this, terceiraac.class);
            startActivity(i);
        }

    }
    public void OnButtonClick2(View v) {
        if (v.getId() == R.id.Bdisplay2) {
            Intent i = new Intent(MainActivity.this, quartaac.class);
            startActivity(i);
        }

    }
    public void OnButtonClick3(View v) {
        if (v.getId() == R.id.Bdisplay3) {
            Intent i = new Intent(MainActivity.this, quintaac.class);
            startActivity(i);
        }

    }


}

